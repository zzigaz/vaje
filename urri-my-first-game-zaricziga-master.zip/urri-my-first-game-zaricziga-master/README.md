Dinamika igre: //bolši opis
	Znašli ste se sredi puščave, kjer se želijo talibani maščevati civilistom, zaradi sodelovanja z američani. Rešiti moramo, kar se da veliko civilistov in se pri tem izmikati nevarnim talibanom.
	Dinamika preproste arkadne igre
Mehanika igre:
	Premikanje vojaka po zaslonu, naključna postavitev talibanov in civilistov, reševanje civilistov, zmaga igre, konec igre
Elementi igre:
	Vojak, civilist, taliban, zdravje vojaka, število rešenih civilistov
